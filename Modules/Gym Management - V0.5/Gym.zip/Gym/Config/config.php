<?php

return [
    'name' => 'Gym',
    'module_version' => '0.5',
    'pid' => '23'
];
