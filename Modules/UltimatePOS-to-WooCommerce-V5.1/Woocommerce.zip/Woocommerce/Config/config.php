<?php

return [
    'name' => 'Woocommerce',
    'module_version' => '5.1',
    'pid' => 22
];
